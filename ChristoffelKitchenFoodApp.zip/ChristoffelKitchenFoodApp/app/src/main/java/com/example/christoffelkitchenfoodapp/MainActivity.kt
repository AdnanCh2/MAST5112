package com.example.christoffelkitchenfoodapp

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

// Define the MenuItem class
data class MenuItem(val name: String, val price: Int, val category: String)

class MainActivity : AppCompatActivity() {

    private val menuItems = listOf(
        MenuItem("Dumplings", 7, "Starter"),
        MenuItem("Soup", 8, "Starter"),
        MenuItem("Vegetable Spring Roll", 5, "Starter"),
        MenuItem("Chicken Pasta", 16, "Main Course"),
        MenuItem("Pizza", 15, "Main Course"),
        MenuItem("Vegetarian Curry with Rice", 13, "Main Course"),
        MenuItem("Apple Crumble", 5, "Dessert"),
        MenuItem("Chocolate Mousse", 9, "Dessert"),
        MenuItem("Peppermint Tart", 6, "Dessert")
    )

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val averagePrice: TextView = findViewById(R.id.averagePrice)

        // Button for Starter category
        findViewById<Button>(R.id.starterButton).setOnClickListener {
            startActivity(Intent(this, Starter::class.java))
            showAveragePrice("Starter", averagePrice)
        }

        // Button for Main Course category
        findViewById<Button>(R.id.mainCourseButton).setOnClickListener {
            startActivity(Intent(this, MainCourse::class.java))
            showAveragePrice("Main Course", averagePrice)
        }

        // Button for Dessert category
        findViewById<Button>(R.id.dessertButton).setOnClickListener {
            startActivity(Intent(this, Dessert::class.java))
            showAveragePrice("Dessert", averagePrice)
        }

        // Button for Cart category
        findViewById<Button>(R.id.viewCartButton).setOnClickListener {
            startActivity(Intent(this, Cart::class.java))
            showAveragePrice("Cart", averagePrice)
        }
    }

    // Function to calculate and show the average price based on the category
    private fun showAveragePrice(category: String, averagePriceTextView: TextView) {
        // Filter the menu items based on the selected category
        val filteredItems = menuItems.filter { it.category == category }

        // Calculate the average price
        if (filteredItems.isNotEmpty()) {
            val averagePrice = filteredItems.map { it.price }.average()
            averagePriceTextView.text = "Average Price: ${"%.2f".format(averagePrice)}"
        } else {
            averagePriceTextView.text = "No items in this category"
        }
    }
}
