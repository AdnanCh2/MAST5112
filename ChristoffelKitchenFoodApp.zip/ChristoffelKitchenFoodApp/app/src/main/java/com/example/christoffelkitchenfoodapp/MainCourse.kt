package com.example.christoffelkitchenfoodapp

import android.annotation.SuppressLint
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button

class MainCourse : AppCompatActivity() {
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main_course)

        findViewById<Button>(R.id.mainCourse1).setOnClickListener {
            Cart.addItem("Chicken Pasta",16)
        }

        findViewById<Button>(R.id.mainCourse2).setOnClickListener {
            Cart.addItem("Pizza",15)
        }

        findViewById<Button>(R.id.mainCourse3).setOnClickListener {
            Cart.addItem("Vegetable Curry and Rice",14)
        }
    }
}