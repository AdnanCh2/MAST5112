package com.example.christoffelkitchenfoodapp

import android.annotation.SuppressLint
import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class Cart : AppCompatActivity() {

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_cart)

        val cartItemsTextView: TextView = findViewById(R.id.cartItems)
        val totalPriceTextView: TextView = findViewById(R.id.totalPrice)

        // Get the cart items and display them
        val items = Cart.getItems()
        val itemDetails = items.joinToString("\n") { "${it.first} - \$${it.second}" }
        cartItemsTextView.text = itemDetails

        // Display the total price
        val totalPrice = Cart.getTotalPrice()
        totalPriceTextView.text = "Total: \$${totalPrice}"
    }


    // Cart Singleton - This ensures that cart items are shared across activities
    object Cart {
        private val items = mutableListOf<Pair<String, Int>>()  // Store items as pairs of name and price

        // Function to add an item to the cart
        fun addItem(name: String, price: Int) {
            items.add(Pair(name, price))
        }

        // Function to get the list of items in the cart
        fun getItems(): List<Pair<String, Int>> = items

        // Function to calculate the total price of items in the cart
        fun getTotalPrice(): Int {
            return items.sumOf { it.second }
        }
    }

    companion object {
        fun addItem(name: String, price: Int) {

        }
    }
}



