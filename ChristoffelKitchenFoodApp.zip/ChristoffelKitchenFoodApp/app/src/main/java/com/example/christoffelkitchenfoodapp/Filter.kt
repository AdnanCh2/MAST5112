package com.example.christoffelkitchenfoodapp

import android.annotation.SuppressLint
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView

class Filter : AppCompatActivity() {

    private val starters = listOf("Dumplings", "Soup", "Vegetarian Spring Roll")
    private val mains = listOf("Chicken Pasta", "Pizza", "Vegetarian Curry with Rice")
    private val desserts = listOf("Apple Crumble", "Chocolate Mousse", "Peppermint Crisp")

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_filter)

        val filterItems = findViewById<TextView>(R.id.filterItems)

        findViewById<Button>(R.id.startersFilterButton).setOnClickListener {
            filterItems.text = "Starters: \n${starters.joinToString("\n")}"
        }

        findViewById<Button>(R.id.mainCourseFilterButton).setOnClickListener {
            filterItems.text = "Main Course: \n${mains.joinToString("\n")}"
        }

        findViewById<Button>(R.id.dessertsFilterButton).setOnClickListener {
            filterItems.text = "Desserts: \n${desserts.joinToString("\n")}"
        }

        findViewById<Button>(R.id.backToMainButton).setOnClickListener {
            startActivity(Intent(this, MainActivity::class.java))
        }
    }
}
