package com.example.christoffelkitchenfoodapp

import android.annotation.SuppressLint
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView

class Menu : AppCompatActivity() {

    private val menuItemsList = mutableListOf(
        "Dumplings", "Soup", "Vegetable Spring Roll", "Chicken Pasta", "Pizza",
        "Vegetarian Curry with Rice", "Apple Crumble", "Chocolate Mousse", "Peppermint Tart"
    )

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_menu)

        // Assign the TextView and buttons to variables
        val menuItemsTextView = findViewById<TextView>(R.id.menuItems)
        val addItemButton = findViewById<Button>(R.id.addItemButton)
        val removeItemButton = findViewById<Button>(R.id.removeItemButton)
        val backButton = findViewById<Button>(R.id.backButton)

        // Display the initial menu items
        updateMenuItems(menuItemsTextView)

        // Add item button listener
        addItemButton.setOnClickListener {
            menuItemsList.add("New Dish")
            updateMenuItems(menuItemsTextView)
        }

        // Remove item button listener
        removeItemButton.setOnClickListener {
            if (menuItemsList.isNotEmpty()) {
                menuItemsList.removeAt(menuItemsList.size - 1)
                updateMenuItems(menuItemsTextView)
            }
        }

        // Back button listener
        backButton.setOnClickListener {
            startActivity(Intent(this, MainActivity::class.java))
        }
    }

    // Helper function to update menu items text
    private fun updateMenuItems(tvMenuItems: TextView) {
        tvMenuItems.text = "Menu Items: \n${menuItemsList.joinToString("\n")}"
    }
}
