package com.example.christoffelkitchenfoodapp

import android.annotation.SuppressLint
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button

class Starter : AppCompatActivity() {
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_starter)

        findViewById<Button>(R.id.starter1).setOnClickListener {
            Cart.addItem("Dumplings",7)
        }

        findViewById<Button>(R.id.starter2).setOnClickListener {
            Cart.addItem("Soup",8)
        }

        findViewById<Button>(R.id.starter3).setOnClickListener {
            Cart.addItem("Vegetable Spring Roll",5)
        }
    }
}