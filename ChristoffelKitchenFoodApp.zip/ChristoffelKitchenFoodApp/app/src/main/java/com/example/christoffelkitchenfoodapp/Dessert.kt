package com.example.christoffelkitchenfoodapp

import android.annotation.SuppressLint
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button

class Dessert : AppCompatActivity() {
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_dessert)

        findViewById<Button>(R.id.dessert1).setOnClickListener {
            Cart.addItem("Apple Crumble",5)
        }

        findViewById<Button>(R.id.dessert2).setOnClickListener {
            Cart.addItem("Chocolate Mousse",9)
        }

        findViewById<Button>(R.id.dessert3).setOnClickListener {
            Cart.addItem("Peppermint Tart",6)
        }
    }
}